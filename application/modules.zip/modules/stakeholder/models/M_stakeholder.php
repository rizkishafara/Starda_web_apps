<?php
class m_stakeholder extends CI_Model
{

	public function tampil_stakeholder()
	{
		$this->db->select('*');
		$this->db->from('user_data');
		$this->db->join('kategori', 'kategori.id_cat = user_data.id_category');
		$this->db->where('status=', 'active');
		$this->db->where('gender!=', 'null');
		return $this->db->get();
	}
	public function tampil_search($keyword)
	{
		$this->db->select('*');
		$this->db->from('user_data');
		$this->db->join('kategori', 'kategori.id_cat = user_data.id_category');
		$this->db->where('status=', 'active');
		$this->db->like('fullname', $keyword);
		$this->db->or_like('category', $keyword);
		$this->db->where('gender!=', 'null');
		return $this->db->get();
	}
	public function tampil_data($id)
	{
		$this->db->select("*");
		$this->db->from("user_data");
		$this->db->join('kategori', 'kategori.id_cat= user_data.id_category');
        $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
		// $this->db->join('user_media', 'user_media.id_user = user_data.id_user');
		// $this->db->join('user_document', 'user_document.id_user = user_data.id_user');
		$this->db->where("user_data.id_user=" . $id);
		return $this->db->get()->row();
	}

	public function tampil_gallery($id)
	{
		$this->db->select('*');
		$this->db->from('user_media');
		$this->db->where('id_user =' . $id);
		$this->db->where('status_media ' , 'Disetujui');
		return $this->db->get();
	}
	public function tampil_document($id)
	{
		$this->db->select('*');
		$this->db->from('user_document');
		$this->db->where('id_user =' . $id);
		$this->db->where('status_doc ' , 'Disetujui');
		return $this->db->get();
	}
	function data($limit, $start)
	{
		// $this->db->select('*');	
		// $this->db->from('user_data', $limit, $start);
		$kategori = $this->db->join('kategori', 'kategori.id_cat = user_data.id_category');
        $kategori = $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
		$status = $this->db->where('status', 'active');
		$gender = $this->db->where('gender !=', '');
		// $this->db->get()->result();
		return $this->db->get('user_data', $limit, $start, $kategori, $status, $gender)->result();
	}
	function dataSearch($limit, $start, $keyword)
	{
		// $this->db->select('*');	
		// $this->db->from('user_data', $limit, $start);
		$kategori = $this->db->join('kategori', 'kategori.id_cat= user_data.id_category');
        $kategori = $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
		$status = $this->db->where('status', 'active');
		$gender = $this->db->where('gender !=', '');
		$katakunci = $this->db->like('fullname', $keyword);
		$katakunci = $this->db->or_like('category', $keyword);
		$katakunci = $this->db->or_like('sub_category', $keyword);
		// $this->db->get()->result();
		return $this->db->get('user_data', $limit, $start, $kategori, $status, $gender, $katakunci)->result();
	}
	public function get_user_keyword($keyword)
	{
		$this->db->select("*");
		$this->db->from("user_data");
		$this->db->join('kategori', 'kategori.id_cat = user_data.id_category');
        $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
		$this->db->where('status', 'active');
		$this->db->where('gender !=', '');
		$this->db->like('fullname', $keyword);
		$this->db->or_like('category', $keyword);
		$this->db->or_like('sub_category', $keyword);
		return $this->db->get();
	}
	public function getCategory()
	{
		$this->db->select('*');
		$this->db->from('kategori');
		return $this->db->get();
	}
	public  function getUserId($id)
	{
		$this->db->select('*');
		$this->db->from('user_data');
		$this->db->join('kategori', 'kategori.id_cat = user_data.id_category');
        $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
		$this->db->where('status', 'active');
		$this->db->where('gender !=', '');
		$this->db->where('user_data.id_category', $id);
		return $this->db->get();
	}
}
