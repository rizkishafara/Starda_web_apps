<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->login_admin->cek_login();
	}
	public function index()
	{
		$data['title'] = 'Dashboard';
		$data['admin'] = $this->db->get_where('admin', ['id_admin' => $this->session->userdata('id_admin')])->row();

		$data['useradmin'] = $this->db->count_all('admin');

		$usermem = $this->db->select('*');
		$usermem = $this->db->from('user_data');
		$usermem = $this->db->where('status', 'active');
		$usermem = $this->db->get();
		$data['usermember'] = $usermem->num_rows();

		$delaymem = $this->db->select('*');
		$delaymem = $this->db->from('user_data');
		$delaymem = $this->db->where('status', 'non active');
		$delaymem = $this->db->get();
		$data['delaymember'] = $delaymem->num_rows();

		$mediapending = $this->db->select('*');
		$mediapending = $this->db->from('user_media');
		$mediapending = $this->db->where('status_media', 'Ditinjau');
		$mediapending = $this->db->get();
		$data['mediapending'] = $mediapending->num_rows();

		$docpending = $this->db->select('*');
		$docpending = $this->db->from('user_document');
		$docpending = $this->db->where('status_doc', 'Ditinjau');
		$docpending = $this->db->get();
		$data['docpending'] = $docpending->num_rows();

		$this->load->view('template/admin/header_view', $data);
		$this->load->view('template/admin/sidebar_view');
		$this->load->view('template/admin/navbar_view', $data);
		$this->load->view('dashboard');
		$this->load->view('template/admin/footer_view');
	}
}
