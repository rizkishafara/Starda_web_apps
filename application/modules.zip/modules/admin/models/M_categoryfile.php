<?php
class m_categoryfile extends CI_Model
{
    public function categoryfile()
    {
        $this->db->select('*');
        $this->db->from('category_file');
        return $this->db->get();
    }
    public function addCategoryFile()
    {
        $data = [
            'cat_file' => $this->input->post('cat_file')

        ];

        $this->db->insert('category_file', $data);
        $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Berhasil ditambahkan</div>');
    }
    public function editCategoryFile($id)
    {
        $this->cat_file = $this->input->post('cat_file');
        $this->db->update('category_file', $this, array('id_cat_file' => $id));
        $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Berhasil diubah</div>');
    }
}
