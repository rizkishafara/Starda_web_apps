<?php
class m_media extends CI_Model
{

    public function media()
    {
        $this->db->select('*');
        $this->db->from('user_media');
        $this->db->join('user_data', 'user_media.id_user=user_data.id_user', 'left');
        $this->db->where('user_media.status_media', '2');
        // $this->db->join('category_file', 'user_media.id_cat_file=category_file.id_cat_file', 'left');
        return $this->db->get();
    }
    public function getMedia($id)
    {
        $this->db->select('*');
        $this->db->from('user_media');
        $this->db->where('id_media =' . $id);
        return $this->db->get();
    }
    public function mediapending()
    {
        $this->db->select('*');
        $this->db->from('user_media');
        $this->db->join('user_data', 'user_media.id_user=user_data.id_user', 'left');
        $this->db->where('user_media.status_media', '1');
        // $this->db->join('category_file', 'user_media.id_cat_file=category_file.id_cat_file', 'left');
        return $this->db->get();
    }
}
