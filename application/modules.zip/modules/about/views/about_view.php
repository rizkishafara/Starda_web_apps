<div class="container text-center">
    <div class="text-center txt-about">
        <h4>Tentang Kami</h4>
        <hr>
    </div>
    <iframe width="620" height="415" src="https://www.youtube.com/embed/4ZX6OpCFtO8">
    </iframe>
    <div class="txt-about">
        <h2>KEMENTERIAN PENDIDIKAN DAN KEBUDAYAAN<br>
            <small>BALAI PENGEMBANGAN MULTIMEDIA PENDIDIKAN DAN KEBUDAYAAN</small>
        </h2>
        <p>Jl. Mr. Koessoebiyono Tjondro Wibowo<br>
            Kel. Pakintelan, Kec Gunung Pati, Kodya Semarang 50227<br>
            Jawa Tengah - Indonesia<br>
            Telp 024-8314292 fax 024-8310051<br></p>
    </div>
    <div class="row txt-about">
        <div class="col-md-6">
            <img class="img-thumbnail" src=<?= base_url('assets/image/about.jpg') ?> alt="">
        </div>
        <div class="col-md-6">
            <div class="mapouter">
                <div class="gmap_canvas"><iframe width="100%" height="353.33" id="gmap_canvas" src="https://maps.google.com/maps?q=bpmpk&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-a.com"></a><br>
                    <style>
                        .mapouter {
                            position: relative;
                            text-align: right;
                            height: 353.33;
                            width: 555px;
                        }
                    </style><a href="https://www.embedgooglemap.net">google html code</a>
                    <style>
                        .gmap_canvas {
                            overflow: hidden;
                            background: none !important;
                            height: 353.33;
                            width: 555px;
                        }
                    </style>
                </div>
            </div>
        </div>
    </div>
</div>