<span style="color: #ff0000;">
<html></span>
<head>
	<meta charset="UTF-8">
	<title>Belajar HMVC di Codeigniter</title>
</head>
<body>
	<h1>Ini adalah halaman login Produk</h1>
</body>
</html>