<?php
class m_usermember extends CI_Model
{
    public function usermember()
    {
        $this->db->select('*');
        $this->db->from('user_data');
        $this->db->join('kategori', 'user_data.id_category=kategori.id_cat','left');
        $this->db->join('sub_kategori', 'user_data.id_sub_category=sub_kategori.id_sub_category','left');
        $this->db->where('status', 'active');
        return $this->db->get();
    }

    // public function resetpassMember($id)
    // {
    //     $this->status ='non active';
    
    //     $this->db->update('user_data', $this, array('id_user' => $id));
    //     $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Berhasil ditambahkan</div>');
    // }


    // public function getusermember($id)
    // {
    //     $this->db->select('*');
    //     $this->db->from('user_data');
    //     $this->db->join('kategori', 'kategori.id_category = user_data.id_category');
    //     $this->db->where('id_user', $id);
    //     return $this->db->get();
    // }
    public function tampil_document($id)
    {
        $this->db->select('*');
        $this->db->from('user_document');
        $this->db->where('id_user =' . $id);
        return $this->db->get();
    }
    public function deleteMember($id)
    {
        // delete profile
        $profile=$this->db->get_where('user_data', ['id_user' => $id])->row();
        unlink(FCPATH . 'storage/profile_user/' . $profile->photo_user);

        // delete user on table
        $this->db->where('id_user', $id);
        $this->db->delete('user_data'); 

        // delete media user
        $media=$this->db->get_where('user_media', ['id_user' => $id])->result_array();

        foreach ($media as $m){
            unlink(FCPATH . 'storage/media_user/' . $m['name_media']);
        }
        $this->db->where('id_user', $id);
        $this->db->delete('user_media');

        // delete document user
        $document=$this->db->get_where('user_document', ['id_user' => $id])->result_array();

        foreach ($document as $doc){
            unlink(FCPATH . 'storage/document_user/' . $doc['name_document']);
        }
        $this->db->where('id_user', $id);
        $this->db->delete('user_document');

        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Data berhasil dihapus</div>');
    }
}
