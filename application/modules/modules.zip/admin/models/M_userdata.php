<?php
require('./application/third_party/phpoffice/vendor/autoload.php');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class m_userdata extends CI_Model
{
    public function userData()
    {
        $this->db->select('*');
        $this->db->from('user_data');
        $this->db->join('kategori', 'kategori.id_cat = user_data.id_category');
        $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
        $this->db->where('user_data.status', 'active');
        return $this->db->get();
    }


    public function getuserData($id)
    {
        $this->db->select('*');
        $this->db->from('user_data');
        $this->db->join('kategori', 'kategori.id_cat = user_data.id_category', 'left');
        $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
        $this->db->where('user_data.id_user', $id);
        return $this->db->get();
    }
    public function tampil_galery($id)
    {
        $this->db->select('*');
        $this->db->from('user_media');
        $this->db->where('id_user =' . $id);
        return $this->db->get();
    }
    public function tampil_document($id)
    {
        $this->db->select('*');
        $this->db->from('user_document');
        $this->db->where('id_user =' . $id);
        return $this->db->get();
    }
    public function getDataExport($id)
    {
        $this->db->select('*');
        $this->db->from('user_data');
        $this->db->join('kategori', 'kategori.id_cat= user_data.id_category');
        $this->db->join('sub_kategori', 'sub_kategori.id_sub_category = user_data.id_sub_category', 'left');
        $this->db->where('id_user', $id);
        return $this->db->get()->row();
    }
    public function getDataExcel($id)
    {
        $user = $this->getuserData($id)->row();

        $spreadsheet = new Spreadsheet;

        // PHPExcel_Shared_Font::setAutoSizeMethod(PHPExcel_Shared_Font::AUTOSIZE_METHOD_EXACT);

        $spreadsheet->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No')
            ->setCellValue('B1', 'Nama')
            ->setCellValue('C1', 'Email')
            ->setCellValue('D1', 'Alamat')
            ->setCellValue('E1', 'HP / Whatsapp')
            ->setCellValue('F1', 'Ketegori')
            ->setCellValue('G1', 'Sub Kategori')
            ->setCellValue('H1', 'Instansi')
            ->setCellValue('I1', 'Gender')
            ->setCellValue('J1', 'Tentang');
        $kolom = 2;
        $nomor = 1;
        $spreadsheet->setActiveSheetIndex(0)
            ->setCellValue('A' . $kolom, $nomor)
            ->setCellValue('B' . $kolom, $user->fullname)
            ->setCellValue('C' . $kolom, $user->email)
            ->setCellValue('D' . $kolom, $user->address_user)
            ->setCellValue('E' . $kolom, $user->phone_user)
            ->setCellValue('F' . $kolom, $user->category)
            ->setCellValue('G' . $kolom, $user->sub_category)
            ->setCellValue('H' . $kolom, $user->instansi)
            ->setCellValue('I' . $kolom, $user->gender)
            ->setCellValue('J' . $kolom, $user->about);
        $kolom++;
        $nomor++;

        foreach (range('A', $spreadsheet->getActiveSheet()->getHighestDataColumn()) as $col) {
            $spreadsheet->getActiveSheet()
                ->getColumnDimension($col)
                ->setAutoSize(true);
        }

        $writer = new Xlsx($spreadsheet);
        $filename = 'Data ' . $user->fullname . '.xlsx';

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename=' . $filename);
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }
    public function getUsersExport()
    {
        $userall = $this->userData()->result();

        $spreadsheet = new Spreadsheet;

        // PHPExcel_Shared_Font::setAutoSizeMethod(PHPExcel_Shared_Font::AUTOSIZE_METHOD_EXACT);

        $spreadsheet->setActiveSheetIndex(0)
            ->setCellValue('A1', 'No')
            ->setCellValue('B1', 'Nama')
            ->setCellValue('C1', 'Email')
            ->setCellValue('D1', 'Alamat')
            ->setCellValue('E1', 'HP / Whatsapp')
            ->setCellValue('F1', 'Ketegori')
            ->setCellValue('G1', 'Sub Kategori')
            ->setCellValue('H1', 'Instansi')
            ->setCellValue('I1', 'Gender')
            ->setCellValue('J1', 'Tentang');
        $kolom = 2;
        $nomor = 1;
        foreach ($userall as $pengguna) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A' . $kolom, $nomor)
                ->setCellValue('B' . $kolom, $pengguna->fullname)
                ->setCellValue('C' . $kolom, $pengguna->email)
                ->setCellValue('D' . $kolom, $pengguna->address_user)
                ->setCellValue('E' . $kolom, $pengguna->phone_user)
                ->setCellValue('F' . $kolom, $pengguna->category)
                ->setCellValue('G' . $kolom, $pengguna->sub_category)
                ->setCellValue('H' . $kolom, $pengguna->instansi)
                ->setCellValue('I' . $kolom, $pengguna->gender)
                ->setCellValue('J' . $kolom, $pengguna->about);
            $kolom++;
            $nomor++;
        }

        foreach (range('A', $spreadsheet->getActiveSheet()->getHighestDataColumn()) as $col) {
            $spreadsheet->getActiveSheet()
                ->getColumnDimension($col)
                ->setAutoSize(true);
        }

        $writer = new Xlsx($spreadsheet);

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Daftar Stakeholder.xlsx"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }
}
