<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Media extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->login_admin->cek_login();
		$this->load->model('m_media');
	}
	public function index()
	{
		$data['title'] = 'Media';
		$data['admin'] = $this->db->get_where('admin', ['id_admin' => $this->session->userdata('id_admin')])->row();

		$data['media'] = $this->m_media->media()->result();

		$this->load->view('template/admin/header_view', $data);
		$this->load->view('template/admin/sidebar_view');
		$this->load->view('template/admin/navbar_view', $data);
		$this->load->view('media/media_v', $data);
		$this->load->view('template/admin/footer_view');
	}
	public function delete_media($id){
		// delete file di storage
        $post =  $this->m_media->getMedia($id)->row_array();
        $media = $post['name_media'];
        unlink(FCPATH . 'storage/media_user/' . $media);

		$this->db->where('id_media', $id);
        $this->db->delete('user_media');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Data berhasil dihapus</div>');
        redirect('admin/Media');
	}
	public function mediapending(){
		$data['title'] = 'Pertinjauan Media';
		$data['admin'] = $this->db->get_where('admin', ['id_admin' => $this->session->userdata('id_admin')])->row();

		$data['mediapending'] = $this->m_media->mediapending()->result();

		$this->load->view('template/admin/header_view', $data);
		$this->load->view('template/admin/sidebar_view');
		$this->load->view('template/admin/navbar_view', $data);
		$this->load->view('media/mediapending_v', $data);
		$this->load->view('template/admin/footer_view');
	}
	public function accept_media($id)
	{
		$this->status_media="2";

		$this->db->update('user_media', $this, array('id_media' => $id));
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Data berhasil disetujui</div>');
		redirect('admin/Media/mediapending');
	}
	public function tolak_media($id)
	{
		$this->status_media="3";

		$this->db->update('user_media', $this, array('id_media' => $id));
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Data berhasil ditolak</div>');
		redirect('admin/Media/mediapending');
	}
}
