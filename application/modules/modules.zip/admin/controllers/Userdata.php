<?php
defined('BASEPATH') or exit('No direct script access allowed');



class Userdata extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->login_admin->cek_login();
        $this->load->model('m_userdata');
        $this->load->library('Pdf');
    }
    public function index()
    {
        $data['title'] = 'Userdata';
        $data['admin'] = $this->db->get_where('admin', ['id_admin' => $this->session->userdata('id_admin')])->row();

        $data['userdata'] = $this->m_userdata->userdata()->result();

        $this->load->view('template/admin/header_view', $data);
        $this->load->view('template/admin/sidebar_view');
        $this->load->view('template/admin/navbar_view', $data);
        $this->load->view('userdata/userdata_v', $data);
        $this->load->view('template/admin/footer_view');
    }
    public function add_data()
    {
        $this->m_userdata->adddata();
        redirect('admin/Userdata');
    }
    public function edit_data($id)
    {
        $this->m_useradmin->editdata($id);
        redirect('admin/Userdata');
    }
    public function delete_data($id)
    {
        $this->db->where('id_user', $id);
        $this->db->delete('user_data');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Data berhasil dihapus</div>');
        redirect('admin/Userdata');
    }
    public function detail_data($id)
    {
        $data['title'] = 'Userdata';
        $data['admin'] = $this->db->get_where('admin', ['id_admin' => $this->session->userdata('id_admin')])->row();

        $data['userdata'] = $this->m_userdata->getuserData($id)->row();
        $data["galery"] = $this->m_userdata->tampil_galery($id)->result();
        $data["document"] = $this->m_userdata->tampil_document($id)->result();

        $this->load->view('template/admin/header_view', $data);
        $this->load->view('template/admin/sidebar_view');
        $this->load->view('template/admin/navbar_view', $data);
        $this->load->view('userdata/detail_v', $data);
        $this->load->view('template/admin/footer_view');
    }
    public function export_pdf($id)
    {
        $data['result'] = $this->m_userdata->getDataExport($id);
        $this->load->view('userdata/cetak_pdf', $data);
    }
    public function export_excel($id)
    {
        $this->m_userdata->getDataExcel($id);
    }
    public function export_user_excel()
    {
        $this->m_userdata->getUsersExport();
    }
}
