<head>
    <meta charset="UTF-8">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href=<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?> integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fontawesome-free/css/all.min.css') ?>">

    <!-- css tambahan -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css+/css.css') ?>">
    <title><?php echo $title;?></title>
</head>