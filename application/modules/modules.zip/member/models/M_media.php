<?php
class m_media extends CI_Model
{

    public function media($id)
    {
        $this->db->select('*');
        $this->db->from('user_media');
        $this->db->join('user_data', 'user_media.id_user=user_data.id_user', 'left');
        $this->db->join('status', 'user_media.status_media=status.id_status', 'left');
        // $this->db->join('category_file', 'user_media.id_cat_file=category_file.id_cat_file', 'left');
        $this->db->where('user_media.id_user', $id);
        return $this->db->get();
    }
    public function getMedia($id)
    {
        $this->db->select('*');
        $this->db->from('user_media');
        $this->db->where('id_media =' . $id);
        return $this->db->get();
    }
    public function addMedia($id_user)
    {

        $config['upload_path']          = 'storage/media_user';
        $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4|mkv|mpeg';
        $random_code = random_string('alnum', 15);
        $config['file_name'] = $id_user . '_media' . $random_code;
        $config['overwrite']            = true;
        $config['max_size']             = 102400;

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('media')) {
            $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Media tidak memenuhi syarat</div>');
            redirect('member/media', $error);
        } else {
            $post = $this->input->post();
            $file = $this->upload->data();
            $fl = new SplFileInfo($file["file_name"]);
            $ext = $fl->getExtension();

            if ($ext == "jpg" or $ext  == "png" or $ext == "jpeg" or $ext == "gif") {
                $this->id_cat_file = "2";
            } else if ($ext == "mp4" or $ext  == "mkv") {
                $this->id_cat_file = "1";
            } else {
                return $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Media gagal ditambahkan</div>');
            }

            $this->id_user = $id_user;
            $this->title_media = $post["title_media"];
            $this->name_media = $file["file_name"];

            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Media berhasil ditambahkan</div>');
            return $this->db->insert("user_media", $this);
        }
    }
    public function editMedia($id)
    {
        $this->title_media = $this->input->post('title_media');
        $this->status_media = "1";
        if (!empty($_FILES["name_media"]["name"])) {
            $this->name_media = $this->_uploadMedia();
        } else {
            $this->name_media = $this->input->post('name_media1');
        }
        $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Media berhasil diubah</div>');
        return $this->db->update('user_media', $this, array('id_media' => $id));
    }
    private function _uploadMedia()
    {
        $id_user = $this->session->userdata('id_user');
        $old_media = $this->input->post('name_media1');

        $config['upload_path']          = 'storage/media_user';
        $config['allowed_types']        = 'gif|jpg|png|jpeg|mp4|mkv|mpeg';
        $random_code = random_string('alnum', 15);
        $config['file_name'] = $id_user . '_media' . $random_code;
        $config['overwrite']            = true;
        $config['max_size']             = 102400;

        $this->upload->initialize($config);

        if (!$this->upload->do_upload('name_media')) {
            $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Media tidak memenuhi syarat</div>');
            redirect('member/media', $error);
        } else {
            $file = $this->upload->data();
            $fl = new SplFileInfo($file["file_name"]);
            $ext = $fl->getExtension();

            if ($ext == "jpg" or $ext  == "png" or $ext == "jpeg" or $ext == "gif") {
                $this->id_cat_file = "2";
            } else if ($ext == "mp4" or $ext  == "mkv") {
                $this->id_cat_file = "1";
            } else {
                return $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Media gagal ditambahkan</div>');
            }
            unlink(FCPATH . '/storage/media_user/' . $old_media);
            return $this->name_media = $file["file_name"];
        }
    }
}
