<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Media User</h1>
    <!-- DataTales Example -->
    <?= $this->session->flashdata('pesan'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 row">
            <h6 class="m-0 font-weight-bold text-primary my-auto">Tabel Data Media User</h6>
            <button class="btn btn-success ml-auto" data-toggle="modal" data-target="#tambahMedia">Tambah</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>Judul Media</th>
                            <th>Thumbnail</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>NO</th>
                            <th>Judul Media</th>
                            <th>Thumbnail</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($media as $doc) {
                            $id = $doc->id_media;
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $doc->title_media ?></td>
                                <td> <?php
                                        if ($doc->id_cat_file == '1') {
                                            echo "<i class='fas fa-file-video' style='font-size: 130px; color:purple;'></i>";
                                        } else if ($doc->id_cat_file == '2') {
                                            echo "<i class='fas fa-file-image' style='font-size: 130px;color:lightblue;'></i>";
                                        }
                                        ?></td>
                                <td><?= $doc->status ?></td>
                                <td>
                                    <button class="btn btn-warning" data-toggle="modal" data-target="#detailMedia/<?= $id ?>">Detail</button>
                                    <button class="btn btn-success" data-toggle="modal" data-target="#editMedia/<?= $id ?>">Edit</button>
                                    <button class="btn btn-danger" data-toggle="modal" data-target="#deleteMedia/<?= $id ?>">Hapus</button>
                                </td>

                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Modal Media -->
<?php
foreach ($media as $g) {
    $id_media = $g->id_media;
?>
    <div class="modal fade" id="detailMedia/<?= $id_media ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">
                        <?= $g->title_media ?>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mx-auto">
                    <?php if ($g->id_cat_file == '1') {
                        echo "<video controls>
                                <source src=" . base_url('storage/media_user/' . $g->name_media) . ">
                            </video>";
                    } else if ($g->id_cat_file == '2') {
                        echo "<img class='' style='width:512px ;height:auto;' src=" . base_url('storage/media_user/' . $g->name_media) . " >";
                    } ?>

                </div>
                <div class="row">
                    <a class="col btn btn-success m-3" href="<?= base_url('profile/download_image/' . $id_media) ?>">Download</a>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<!-- Modal tambah media-->
<?php $id_user = $this->session->userdata('id_user') ?>
<div class="modal fade" id="tambahMedia" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Tambah</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action=<?= base_url('member/media/add_media/' . $id_user) ?> method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <label for="title">Judul</label>
                    <div class="form-label-group mb-3">
                        <input type="text" id="inputTitle" accept="file_extension" autocomplete="off" name="title_media" class="form-control" placeholder="Judul Media" required autofocus>
                    </div>
                    <?= form_error('title_media', '<small class="text-danger pl-3">', '</small>'); ?>

                    <div class="mb-3">
                        <input type="file" name="media" id="media" multiple="true" class="form-control form-control-lg mb-2" required>
                        <span style="color: red;">*Max size : 100 MB</span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal edit media-->
<?php foreach ($media as $doc) { ?>
    <div class="modal fade" id="editMedia/<?= $doc->id_media ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Edit</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action=<?= base_url('member/media/edit_media/' . $doc->id_media) ?> method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        <label for="title">Judul</label>
                        <div class="form-label-group mb-3">
                            <input type="text" id="inputTitle" accept="file_extension" autocomplete="off" value="<?= $doc->title_media ?>" name="title_media" class="form-control" placeholder="Judul Document" required autofocus>
                        </div>
                        <?= form_error('title_media', '<small class="text-danger pl-3">', '</small>'); ?>
                        <span>current file : <?= $doc->name_media ?></span>

                        <div class="mb-3">
                            <input type="hidden" value="<?= $doc->name_media ?>" name="name_media1" id="name_media1">
                            <input type="file" name="name_media" id="name_media" multiple="true" class="form-control form-control-lg mb-2">
                            <span style="color: red;">*Max size : 100 MB</span>
                        </div>
                        <?= form_error('name_media', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="save" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>

<!-- Modal delete -->
<?php foreach ($media as $doc) {
    $id = $doc->id_media; ?>
    <div class="modal fade" id="deleteMedia/<?= $id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Yakin untuk menghapus media <?= $doc->title_media ?> ?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <a type="button" class="btn btn-danger" href="<?= base_url('member/media/delete_media/' . $id) ?>">Hapus</a>
                </div>
            </div>
        </div>
    </div>
<?php } ?>