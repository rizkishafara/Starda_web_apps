<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Media extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->login_admin->cek_member();
		$this->load->model('m_media');
	}
	public function index()
	{
		$data['title'] = 'Gellery';
		$data['user'] = $this->db->get_where('user_data', ['id_user' => $this->session->userdata('id_user')])->row();

		$id=$this->session->userdata('id_user');
		$data['media'] = $this->m_media->media($id)->result();

		$this->load->view('template/member/header_view', $data);
		$this->load->view('template/member/sidebar_view');
		$this->load->view('template/member/navbar_view', $data);
		$this->load->view('media/media_v', $data);
		$this->load->view('template/member/footer_view');
	}
	public function add_media($id_user)
    {
        $this->m_media->addMedia($id_user);
        redirect('member/media');
    }
	public function edit_media($id)
    {
        $this->m_media->editMedia($id);
        redirect('member/media');
    }
	public function delete_media($id){
		// delete file di storage
        $post =  $this->m_media->getMedia($id)->row_array();
        $media = $post['name_media']; 
        unlink(FCPATH . 'storage/media_user/' . $media);

		$this->db->where('id_media', $id);
        $this->db->delete('user_media');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Data berhasil dihapus</div>');
        redirect('member/Media');
	}
}
