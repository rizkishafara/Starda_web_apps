<div id="thumbCarousel" class="carousel slide">
	<div class="carousel-inner">
		<?php
		$i = 0;
		foreach ($this->partner_images as $sr) {
		?>
			<?php if ($i == 0) { ?><div class="item active"><?php } ?>
				<?php if ($i % 2 == 0) { ?><div class="item"><?php } ?>
					<div class="col-xs-3">
						<a href="<?php echo $sr['url']; ?>">
							<img src="<?php echo base_url() ?>/partner-images/<?php echo $sr['name'] ?>" />
						</a>
					</div>
					<?php
					if ($i % 4 != 0) {
					?>
					</div><?php } ?>
			<?php $i++;
		} ?>
				</div>
				<a class="thumbleft" href="#thumbCarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
				<a class="thumbright" href="#thumbCarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span> </a>

	</div>
</div>